﻿using System;

class WriteMyFirstLastName
{
    static void Main()
    {
        string firstName = "Stanislava";
        string lastName = "Hristova";
        Console.WriteLine(firstName + " " + lastName);
    }
}

