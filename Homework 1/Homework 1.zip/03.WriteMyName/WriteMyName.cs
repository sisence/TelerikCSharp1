﻿using System;

class WriteMyName
{
    static void Main()
    {
        Console.WriteLine("Stanislava");
        Console.ReadLine();
        Console.Beep();
    }
}

