﻿//4: Declare an integer variable and assign it with the value 254 in hexadecimal format. 

using System;


class HexadecimalFormat
{
    static void Main()
    {
        int theNum = 254;
        Console.WriteLine("The hexadecimal format of the number 254 is {0:X}", theNum);
    }
}

